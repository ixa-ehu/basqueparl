The BasqueParl corpus is licensed under a Creative Commons Attribution 4.0 International License:

https://creativecommons.org/licenses/by/4.0/legalcode
